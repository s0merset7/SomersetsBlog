<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html>
	<head>
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" type="text/css" href="./styles/global-styles.css" />
	</head>
	<body>
		<div>&nbsp;</div>
		<div class="page-title">Setting up the database...</div><br /><br />
		<span style="text-align: center;">
			<div>&nbsp;</div>
			<div class="label">If you see no error messages, it should be done.</div>
			<div>&nbsp;</div>
			<div class="label"><a href="index.php">Continue back to the frontpage.</a></div>
		</span>
		<br /><br />
		<script>
			try{
				window.sessionStorage.clear();
				window.localStorage.clear();
			}catch(e){
				alert("Error clearing HTML 5 Local and Session Storage" + e.toString());
			};
		</script>
		<div class="database-success-message">HTML 5 Local and Session Storage cleared unless error popped-up already.</div>
<div class="database-success-message">Connected to MySQL database</div><div class="database-success-message">Executed query 'DROP DATABASE IF EXISTS' with result 1</div><div class="database-success-message">Executed query 'CREATE DATABASE' with result 1</div><div class="database-success-message">Executed query 'USE DATABASE' with result 1</div><div class="database-success-message">Executed query 'CREATE TABLE' with result 1</div><div class="database-success-message">Executed query 'CREATE TABLE' with result 1</div><div class="database-success-message">Executed query 'CREATE TABLE' with result 1</div><div class="database-success-message">Executed query 'INSERT INTO TABLE' with result 1</div><div class="database-success-message">Executed query 'INSERT INTO TABLE' with result 1</div><div class="database-success-message">Executed query 'CREATE TABLE' with result 1</div><div class="database-success-message">Executed query 'INSERT INTO TABLE' with result 1</div><div class="database-success-message">Executed query 'CREATE TABLE' with result 1</div><div class="database-success-message">Executed query 'INSERT INTO TABLE' with result 1</div><div class="database-success-message">Executed query 'CREATE TABLE' with result 1</div><div class="database-success-message">Executed query 'CREATE PROCEDURE' with result 1</div><div class="database-success-message">Executed query 'CREATE PROCEDURE' with result 1</div><div class="database-success-message">Executed query 'CREATE PROCEDURE' with result 1</div><div class="database-success-message">Executed query 'CLOSE DATABASE' with result 1</div><script>if(confirm("No PHP or MySQL errors were detected when resetting the database.\n\nClick OK to proceed or Cancel to stay on this page.")){document.location="http://192.168.122.222/mutillidae/"};</script>
	</body>
</html>
