
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html>
<head>
	<meta content="text/html; charset=us-ascii" http-equiv="content-type">

	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
	<link rel="stylesheet" type="text/css" href="./styles/global-styles.css" />
	<link rel="stylesheet" type="text/css" href="./styles/ddsmoothmenu/ddsmoothmenu.css" />
	<link rel="stylesheet" type="text/css" href="./styles/ddsmoothmenu/ddsmoothmenu-v.css" />

	<script type="text/javascript" src="./javascript/bookmark-site.js"></script>
	<script type="text/javascript" src="./javascript/ddsmoothmenu/ddsmoothmenu.js"></script>
	<script type="text/javascript" src="./javascript/ddsmoothmenu/jquery.min.js">
		/***********************************************
		* Smooth Navigational Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
		* This notice MUST stay intact for legal use
		* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
		***********************************************/
	</script>
	<script type="text/javascript">
		ddsmoothmenu.init({
			mainmenuid: "smoothmenu1", //menu DIV id
			orientation: 'v', //Horizontal or vertical menu: Set to "h" or "v"
			classname: 'ddsmoothmenu', //class added to menu's outer DIV
			//customtheme: ["#cccc44", "#cccccc"],
			contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
		});
	</script>

	<script type="text/javascript">
		var onLoadOfBody = function(theBody){
			var l_securityLevel = '5';
						var l_hintsStatus = 'Disabled (0 - I try harder)';
			
			switch(l_securityLevel){
				case "0": var l_securityLevelDescription = 'Hosed'; break;
				case "1": var l_securityLevelDescription = 'Arrogent'; break;
				case "2": var l_securityLevelDescription = '2'; break;
				case "3": var l_securityLevelDescription = '3'; break;
				case "4": var l_securityLevelDescription = '4'; break;
				case "5": var l_securityLevelDescription = 'Secure'; break; 
			}// end switch
			//document.getElementById("idSystemInformationHeading").innerHTML = l_loginMessage;
			document.getElementById("idHintsStatusHeading").innerHTML = 'Hints: ' + l_hintsStatus;
			document.getElementById("idSecurityLevelHeading").innerHTML = 'Security Level: ' + l_securityLevel + ' (' + l_securityLevelDescription + ')';
		}// end function onLoadOfBody()
	</script>
</head>
<body onload="onLoadOfBody(this);">
<table class="main-table-frame" border="1px" cellspacing="0px" cellpadding="0px">
	<tr>
		<td bgcolor="#ccccff" align="center" colspan="7">
			<table width="100%">
				<tr>
					<td style="text-align:center;">
						<span style="text-align:center; font-weight: bold; font-size:30px; text-align: center;">
						<img style="vertical-align: middle; margin-right: 25px;" border="0px" width="75px" height="50px" align="top" src="./images/coykillericon.png"/>
							Mutillidae: Born to be Hacked
						</span>
					</td>
				</tr>		
			</table>
		</td>
	</tr>
	<tr>
		<td bgcolor="#ccccff" align="center" colspan="7">
						<span class="version-header">Version: 2.1.19</span>
			<span id="idSecurityLevelHeading" class="version-header" style="margin-left: 40px;"></span>
			<span id="idHintsStatusHeading" class="version-header" style="margin-left: 40px;"></span>
			<span id="idSystemInformationHeading" class="version-header" style="margin-left: 40px;">Not Logged In</span>
		</td>
	</tr>
	<tr>
		<td colspan="2" class="header-menu-table">
			<table class="header-menu-table">
				<tr>
					<td><a href="index.php?page=home.php">Home</a></td>
					<td>
						<a href="./index.php?page=login.php">Login/Register</a>		
					</td>
										<td><a href="./index.php?do=toggle-security&page=browser-info.php">Toggle Security</a></td>
					<td><a href="set-up-database.php">Reset DB</a></td>
					<td><a href="./index.php?page=show-log.php">View Log</a></td>
					<td><a href="./index.php?page=captured-data.php">View Captured Data</a></td>
				</tr>
			</table>	
		</td>
	</tr>
	<tr>
		<td style="vertical-align:top;text-align:left;background-color:#ccccff;width:10%">
		<div id="smoothmenu1" class="ddsmoothmenu">
			<ul>
				<li style="border-color: #ffffff;border-style: solid;border-width: 1px">
					<a href="#">Core Controls</a>
					<ul>
						<li><a href="index.php?page=home.php">Home</a></li>
					  	<li>
					  		<a href="./index.php?page=login.php">Login/Register</a>						</li>
						<li><a href="./index.php?do=toggle-security&page=browser-info.php">Toggle Security</a></li>
						<li><a href="set-up-database.php">Setup/Reset the DB</a></li>
						<li><a href="./index.php?page=show-log.php">Show Log</a></li>
						<li><a href="./index.php?page=credits.php">Credits</a></li>
					</ul>
				</li>
				<li style="border-color: #ffffff;border-style: solid;border-width: 1px">
					<a href="#">OWASP Top 10</a>
					<ul>
						<li>
							<a href="http://www.owasp.org/index.php/Top_10_2010-A1" target="_blank">A1 - Injection</a>
							<ul>
								<li>
									<a href="">SQLi - Extract Data</a>
									<ul>
										<li><a href="./index.php?page=user-info.php">User Info</a></li>
									</ul>
								</li>
								<li>
									<a href="">SQLi - Bypass Authentication</a>
									<ul>
										<li><a href="./index.php?page=login.php">Login</a></li>
									</ul>
								</li>
								<li>
									<a href="">SQLi - Insert Injection</a>
									<ul>
										<li><a href="./index.php?page=register.php">Register</a></li>
									</ul>
								</li>
								<li>
									<a href="">Blind SQL via Timing</a>
									<ul>
										<li><a href="./index.php?page=login.php">Login</a></li>
										<li><a href="./index.php?page=user-info.php">User Info</a></li>
									</ul>
								</li>
								<li>
									<a href="">SQLMAP Practice Target</a>
									<ul>
										<li><a href="./index.php?page=view-someones-blog.php">View Someones Blog</a></li>
										<li><a href="./index.php?page=user-info.php">User Info</a></li>
									</ul>
								</li>
								<li>
									<a href="">HTML Injection (HTMLi)</a>
									<ul>
										<li><a href="?page=add-to-your-blog.php">Add to your blog</a></li>
									</ul>
								</li>
								<li>
									<a href="">HTMLi via HTTP Headers</a>
									<ul>
										<li><a href="./index.php?page=site-footer-xss-discussion.php">Site Footer</a><li>
										<li><a href="">HTTP Response Splitting (Hint: Difficult)</a></li>
									</ul>
								</li>
								<li>
									<a href="">HTMLi Via DOM Injection</a>
									<ul>
										<li><a href="index.php?page=html5-storage.php">HTML5 Storage</a></li>
									</ul>
								</li>								
								<li>
									<a href="">HTMLi Via Cookie Injection</a>
									<ul>
										<li><a href="index.php?page=capture-data.php">Capture Data Page</a></li>
									</ul>
								</li>
								<li>
									<a href="">Command Injection</a>
									<ul>
										<li><a href="./index.php?page=dns-lookup.php">DNS Lookup</a></li>
									</ul>
								</li>
								<li>
									<a href="">JavaScript Injection</a>
									<ul>
										<li><a href="./index.php">Those "Back" Buttons</a></li>
										<li>
											<a href="./index.php?page=password-generator.php&username=anonymous">
												Password Generator
											</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="">HTTP Parameter Pollution</a>
									<ul>
										<li><a href="./index.php?page=user-poll.php">Poll Question</a></li>
									</ul>
								</li>
								<li>
									<a href="">Cascading Style Injection</a>
									<ul>
										<li><a href="./index.php?page=set-background-color.php">Set Background Color</a></li>
									</ul>
								</li>
								<li>
									<a href="">JavaScript Object Notation (JSON) Injection</a>
									<ul>
										<li><a href="./index.php?page=pen-test-tool-lookup.php">Pen Test Tool Lookup</a></li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="http://www.owasp.org/index.php/Top_10_2010-A2" target="_blank">A2 - Cross Site Scripting (XSS)</a>
							<ul>
								<li>
									<a href="">Reflected (First Order)</a>
									<ul>
										<li><a href="./index.php?page=dns-lookup.php">DNS Lookup</a></li>
										<li><a href="./index.php?page=pen-test-tool-lookup.php">Pen Test Tool Lookup</a></li>
										<li><a href="./index.php?page=text-file-viewer.php">Text File Viewer</a></li>
										<li><a href="./index.php?page=user-info.php">User Info</a></li>
										<li><a href="./index.php?page=set-background-color.php">Set Background Color</a></li>
										<li><a href="./index.php?page=html5-storage.php">HTML5 Storage</a></li>
										<li><a href="./index.php?page=capture-data.php">Capture Data Page</a></li>
									</ul>
								</li>
								<li>
									<a href="">Persistent (Second Order)</a>
									<ul>
										<li><a href="?page=add-to-your-blog.php">Add to your blog</a></li>
										<li><a href="?page=view-someones-blog.php">View someone's blog</a></li>
										<li><a href="?page=show-log.php">Show Log</a><li>
									</ul>
								</li>
								<li>
									<a href="">DOM Injection</a>
									<ul>
										<li><a href="index.php?page=html5-storage.php">HTML5 Storage</a></li>
									</ul>
								</li>								
								<li>
									<a href="">Via "Input" (GET/POST)</a>
									<ul>
										<li><a href="?page=add-to-your-blog.php">Add to your blog</a></li>
										<li><a href="?page=view-someones-blog.php">View someone's blog</a></li>
										<li><a href="?page=show-log.php">Show Log</a><li>
										<li><a href="?page=text-file-viewer.php">Text File Viewer</a></li>
										<li><a href="./index.php?page=dns-lookup.php">DNS Lookup</a></li>
										<li><a href="?page=user-info.php">User Info</a></li>
										<li><a href="./index.php">Missing HTTPOnly Attribute</a></li>
										<li><a href="./index.php?page=set-background-color.php">Set Background Color</a></li>
										<li><a href="./index.php?page=pen-test-tool-lookup.php">Pen Test Tool Lookup</a></li>
									</ul>
								</li>
								<li>
									<a href="">Via HTTP Headers</a>
									<ul>
										<li><a href="./index.php?page=browser-info.php">Browser Info</a></li>
										<li><a href="./index.php?page=show-log.php">Show Log</a><li>
										<li><a href="./index.php?page=site-footer-xss-discussion.php">Site Footer</a><li>
										<li><a href="./index.php?page=html5-storage.php">Those &quot;BACK&quot; Buttons</a></li>
									</ul>
								</li>
								<li>
									<a href="">Via Misconfiguration</a>
									<ul>
										<li><a href="./index.php">Missing HTTPOnly Attribute</a></li>
									</ul>
								</li>
								<li>
									<a href="">Against HTML 5 Storage</a>
									<ul>
										<li><a href="index.php?page=html5-storage.php">HTML5 Storage</a></li>
									</ul>
								</li>
								<li>
									<a href="">Against JSON</a>
									<ul>
										<li><a href="./index.php?page=pen-test-tool-lookup.php">Pen Test Tool Lookup</a></li>
									</ul>
								</li>
								<li>
									<a href="">Via Cookie Injection</a>
									<ul>
										<li><a href="index.php?page=capture-data.php">Capture Data Page</a></li>
									</ul>
								</li>					
							</ul>
						</li>
						<li>
							<a href="http://www.owasp.org/index.php/Top_10_2010-A3" target="_blank">
								A3 - Broken Authentication and Session Management
							</a>
							<ul>
								<li><a href="index.php">Cookies</a></li>
								<li><a href="?page=login.php">Login</a></li>
							</ul>
						</li>
						<li>
							<a href="http://www.owasp.org/index.php/Top_10_2010-A4" target="_blank">A4 - Insecure Direct Object References</a>
							<ul>
								<li><a href="index.php?page=text-file-viewer.php">Text File Viewer</a></li>
								<li><a href="index.php?page=source-viewer.php">Source Viewer</a></li>
								<li><a href="index.php?page=credits.php">Credits</a></li>
								<li><a href="index.php">Cookies</a></li>
								<li><a href="index.php?page=arbitrary-file-inclusion.php">Arbitrary File Inclusion</a></li>
							</ul>
						</li>
						<li>
							<a href="http://www.owasp.org/index.php/Top_10_2010-A5" target="_blank">A5 - Cross Site Request Forgery (CSRF)</a>
							<ul>
								<li><a href="index.php?page=add-to-your-blog.php">Add to your blog</a></li>
								<li><a href="./index.php?page=register.php">Register User</a></li>
							</ul>
						</li>
						<li>
							<a href="http://www.owasp.org/index.php/Top_10_2010-A6" target="_blank">A6 - Security Misconfiguration</a>
							<ul>
								<li><a href="index.php?page=home.php">Directory Browsing</a></li>
								<li><a href="./index.php?page=user-info.php">GET for POST</a></li>
							</ul>
						</li>
						<li>
							<a href="http://www.owasp.org/index.php/Top_10_2010-A7" target="_blank">A7 - Insecure Cryptographic Storage</a>
							<ul>
								<li><a href="index.php?page=user-info.php">User Info</a></li>
								<li><a href="index.php?page=html5-storage.php">HTML5 Storage</a></li>
							</ul>
						</li>
						<li>
							<a href="http://www.owasp.org/index.php/Top_10_2010-A8" target="_blank">A8 - Failure to Restrict URL Access</a>
							<ul>
								<li><a href="index.php?page=secret-administrative-pages.php">"Secret" Administrative Pages</a></li>
								<li><a href="http://en.wikipedia.org/wiki/Robots_exclusion_standard">Robots.txt</a></li>
							</ul>
						</li>
						<li>
							<a href="http://www.owasp.org/index.php/Top_10_2010-A9" target="_blank">A9 - Insufficient Transport Layer Protection</a>
							<ul>
								<li><a href="?page=login.php">Login</a></li>
								<li><a href="?page=user-info.php">User Info</a></li>
							</ul>
						</li>
						<li>
							<a href="http://www.owasp.org/index.php/Top_10_2010-A10" target="_blank">A10 - Unvalidated Redirects and Forwards</a>
							<ul>
								<li><a href="?page=credits.php">Credits</a></li>
																<a href="#">Setup/reset the DB (Disabled: Not Admin)</a></li>
										
							</ul>
						</li>
					</ul>
				</li>
				<li style="border-color: #ffffff; border-style: solid;border-width: 1px">
					<a href="#">Others</a>
					<ul>
						<li>
							<a href="http://www.owasp.org/index.php/Top_10_2007-A3" target="_blank">OWASP 2007 A3 - Malicious File Execution</a>
							<ul>
								<li><a href="?page=text-file-viewer.php">Text File Viewer</a></li>
								<li><a href="?page=source-viewer.php">Source Viewer</a></li>
							</ul>		
						</li>
						<li>
							<a href="http://www.owasp.org/index.php/Top_10_2007-A6" target="_blank">OWASP 2007 A6 - Information Leakage and Improper Error Handling</a>
							<ul>
								<li><a href="index.php">Cache Control</a></li>
								<li><a href="index.php">X-Powered-By HTTP Header</a></li>
								<li><a href="index.php">HTML/JavaScript Comments</a></li>
								<li><a href="index.php?page=framing.php">Click-Jacking</a></li>
								<li><a href="framer.html">Cross-Site Framing (Third-Party Framing)</a></li>
								<li><a href="index.php?page=html5-storage.php">HTML5 Storage</a></li>
							</ul>		
						</li>
						<li>
							<a href="">Denial of Service</a>
							<ul>
								<li><a href="?page=text-file-viewer.php">Text File Viewer</a></li>
								<li><a href="?page=show-log.php">Show Web Log</a><li>
							</ul>		
						</li>
						<li>
							<a href="">JavaScript "Security"</a>
							<ul>
								<li><a href="index.php?page=login.php">Login</a></li>
								<li><a href="index.php?page=add-to-your-blog.php">Add to your blog</a></li>
								<li><a href="index.php?page=html5-storage.php">HTML5 Storage</a></li>
							</ul>		
						</li>
						<li>
							<a href="">Data Capture Pages</a>
							<ul>
								<li><a href="index.php?page=capture-data.php">Data Capture</a></li>
								<li><a href="index.php?page=captured-data.php">View Captured Data</a></li>
							</ul>		
						</li>
					</ul>
				</li>
				<li style="border-color: #ffffff;border-style: solid;border-width: 1px">
					<a href="#">Documentation</a>
					<ul>
						<li><a href="index.php?page=change-log.htm">Change Log</a></li>
						<li><a href="index.php?page=installation.php">Installation Instructions</a></li>
						<li><a href="/mutillidae/documentation/mutillidae-installation-on-xampp-win7.pdf">Installation Instructions: Windows 7 (PDF)</a></li>
						<li><a href="index.php?page=documentation/vulnerabilities.php">Listing of Vulnerabilities</a></li>
						<li>
							<a href="index.php?page=documentation/how-to-access-Mutillidae-over-Virtual-Box-network.php" target="_blank">
								How to Access Mutillidae over Virtual Box "Host Only" Network
							</a>
						</li>
					</ul>
				</li>
				<li style="border-color: #ffffff;border-style: solid;border-width: 1px">
					<a href="#">Resources</a>
					<ul>
						<li>
							<a onclick="bookmarkSite();" href="">
								Bookmark Site
							</a>
						</li>
						<li>
							<a href="https://www.owasp.org/index.php/Top_Ten" target="_blank">
								OWASP Top Ten
							</a>
						</li>
						<li>
							<a href="http://samurai.inguardians.com/" target="_blank">
								Samurai Web Testing Framework
							</a>
						</li>
						<li>
							<a href="https://addons.mozilla.org/en-US/firefox/collections/jdruin/pro-web-developer-qa-pack/" target="_blank">
								Professional Web Application Developer Quality Assurance Pack
							</a>
						</li>
						<li>
							<a href="http://www.irongeek.com/i.php?page=security/mutillidae-deliberately-vulnerable-php-owasp-top-10" target="_blank">
								Latest Version of Mutillidae
							</a>
						</li>
						
						<li>
							<a href="http://www.hackersforcharity.org/ghdb/" target="_blank">
								Google Hacking Database
							</a>
						</li>	
					</ul>
				</li>
			</ul>
			<br style="clear: left" />
		</div>
		<div style="text-align: center;">
			<a href="https://www.owasp.org" target="_blank">
				<img alt="OWASP" style="border-width: 0px;" height="120px" width="160px" src="./images/owasp-logo-400-300.png" />
			</a>
		</div>
		<div class="label" style="text-align: center;">
			Site hacked...err...quality-tested with Samurai WTF, Backtrack, Firefox, Burp-Suite, Netcat, and 
			<a href="https://addons.mozilla.org/en-US/firefox/collections/jdruin/pro-web-developer-qa-pack/" style="text-decoration: none;">
			these Mozilla Add-ons
			</a>
		</div>
		<div>&nbsp;</div>
		<div>&nbsp;</div>
		<div class="label" style="text-align: center;">
			<a href="https://twitter.com/webpwnized" style="text-decoration: none;" target="_blank">
				<img align="middle" alt="Twitter" src="./images/twitter.gif" width="52px" height="35px" />
				<br/>
				@webpwnized
			</a>
		</div>		
		<div>&nbsp;</div>
		<div class="label" style="text-align: center;">
			<a href="http://www.youtube.com/user/webpwnized" style="text-decoration: none; white-space:nowrap;" target="_blank">
				<img align="middle" alt="YouTube" src="./images/youtube_256_256.png" width="56px" height="56px" />
				<br/>
				Mutillidae<br/>Channel
			</a>
		</div>		
		<div>&nbsp;</div>
		<div class="label" style="text-align: center;">Developed by Adrian &quot;<a href="http://www.irongeek.com">Irongeek</a>&quot; Crenshaw and Jeremy Druin</div>
	</td>

<td valign="top">
	<blockquote>
	<!-- Begin Content -->

<div class="page-title">Browser Information</div>


<div style="margin: 5px;">
	<span style="font-weight: bold;" title="Click to return to the last page. It seems this button gets its value from the HTTP Referer field and places this value into a JavaScript.">
	<a 	onclick="document.location.href='http\x3A\x2F\x2F192.168.122.222\x2Fmutillidae\x2F';" 
		style="cursor:pointer;">
		<img	src="./images/back-button-128px-by-128px.png" 
				alt="Back" 
				width="64px" 
				height="64px" 
				align="middle" 
		/>
		&nbsp;
		Back
	</a>
	</span>
</div>
<table border="1px" width="75%" class="main-table-frame">
	<tr class="report-header"><td colspan="3">Info obtained by PHP</td></tr>
	<tr><td class="non-wrapping-label">Client IP</td><td>192.168.122.1</td></tr>
    <tr><td class="non-wrapping-label">Client Hostname</td><td>192.168.122.1</td></tr>
    <tr><td class="non-wrapping-label">Operating System</td><td>Windows 98&#x29;</td></tr>
    <tr><td class="non-wrapping-label">User Agent String</td><td>Mozilla&#x2f;4.5 &#x28;compatible&#x3b; HTTrack 3.0x&#x3b; Windows 98&#x29;</td></tr>
    <tr><td class="non-wrapping-label">Referrer</td><td>http&#x3a;&#x2f;&#x2f;192.168.122.222&#x2f;mutillidae&#x2f;</td></tr>
    <tr><td class="non-wrapping-label">Remote Client Port</td><td>42620</td></tr>
    <tr><td class="non-wrapping-label">WhoIs info for client IP</td><td><pre>&#xa;&#x23;&#xa;&#x23; ARIN WHOIS data and services are subject to the Terms of Use&#xa;&#x23; available at&#x3a; https&#x3a;&#x2f;&#x2f;www.arin.net&#x2f;resources&#x2f;registry&#x2f;whois&#x2f;tou&#x2f;&#xa;&#x23;&#xa;&#x23; If you see inaccuracies in the results, please report at&#xa;&#x23; https&#x3a;&#x2f;&#x2f;www.arin.net&#x2f;resources&#x2f;registry&#x2f;whois&#x2f;inaccuracy_reporting&#x2f;&#xa;&#x23;&#xa;&#x23; Copyright 1997-2021, American Registry for Internet Numbers, Ltd.&#xa;&#x23;&#xa;&#xa;&#xa;&#x23;&#xa;&#x23; Query terms are ambiguous.  The query is assumed to be&#x3a;&#xa;&#x23;     &quot;n 192.168.122.1&quot;&#xa;&#x23;&#xa;&#x23; Use &quot;&#x3f;&quot; to get help.&#xa;&#x23;&#xa;&#xa;NetRange&#x3a;       192.168.0.0 - 192.168.255.255&#xa;CIDR&#x3a;           192.168.0.0&#x2f;16&#xa;NetName&#x3a;        PRIVATE-ADDRESS-CBLK-RFC1918-IANA-RESERVED&#xa;NetHandle&#x3a;      NET-192-168-0-0-1&#xa;Parent&#x3a;         NET192 &#x28;NET-192-0-0-0-0&#x29;&#xa;NetType&#x3a;        IANA Special Use&#xa;OriginAS&#x3a;       &#xa;Organization&#x3a;   Internet Assigned Numbers Authority &#x28;IANA&#x29;&#xa;RegDate&#x3a;        1994-03-15&#xa;Updated&#x3a;        2013-08-30&#xa;Comment&#x3a;        These addresses are in use by many millions of independently operated networks, which might be as small as a single computer connected to a home gateway, and are automatically configured in hundreds of millions of devices.  They are only intended for use within a private context  and traffic that needs to cross the Internet will need to use a different, unique address.&#xd;&#xa;Comment&#x3a;        &#xd;&#xa;Comment&#x3a;        These addresses can be used by anyone without any need to coordinate with IANA or an Internet registry.  The traffic from these addresses does not come from ICANN or IANA.  We are not the source of activity you may see on logs or in e-mail records.  Please refer to http&#x3a;&#x2f;&#x2f;www.iana.org&#x2f;abuse&#x2f;answers&#xd;&#xa;Comment&#x3a;        &#xd;&#xa;Comment&#x3a;        These addresses were assigned by the IETF, the organization that develops Internet protocols, in the Best Current Practice document, RFC 1918 which can be found at&#x3a;&#xd;&#xa;Comment&#x3a;        http&#x3a;&#x2f;&#x2f;datatracker.ietf.org&#x2f;doc&#x2f;rfc1918&#xa;Ref&#x3a;            https&#x3a;&#x2f;&#x2f;rdap.arin.net&#x2f;registry&#x2f;ip&#x2f;192.168.0.0&#xa;&#xa;&#xa;&#xa;OrgName&#x3a;        Internet Assigned Numbers Authority&#xa;OrgId&#x3a;          IANA&#xa;Address&#x3a;        12025 Waterfront Drive&#xd;&#xa;Address&#x3a;        Suite 300&#xa;City&#x3a;           Los Angeles&#xa;StateProv&#x3a;      CA&#xa;PostalCode&#x3a;     90292&#xa;Country&#x3a;        US&#xa;RegDate&#x3a;        &#xa;Updated&#x3a;        2012-08-31&#xa;Ref&#x3a;            https&#x3a;&#x2f;&#x2f;rdap.arin.net&#x2f;registry&#x2f;entity&#x2f;IANA&#xa;&#xa;&#xa;OrgTechHandle&#x3a; IANA-IP-ARIN&#xa;OrgTechName&#x3a;   ICANN&#xa;OrgTechPhone&#x3a;  &#x2b;1-310-301-5820 &#xa;OrgTechEmail&#x3a;  abuse&#x40;iana.org&#xa;OrgTechRef&#x3a;    https&#x3a;&#x2f;&#x2f;rdap.arin.net&#x2f;registry&#x2f;entity&#x2f;IANA-IP-ARIN&#xa;&#xa;OrgAbuseHandle&#x3a; IANA-IP-ARIN&#xa;OrgAbuseName&#x3a;   ICANN&#xa;OrgAbusePhone&#x3a;  &#x2b;1-310-301-5820 &#xa;OrgAbuseEmail&#x3a;  abuse&#x40;iana.org&#xa;OrgAbuseRef&#x3a;    https&#x3a;&#x2f;&#x2f;rdap.arin.net&#x2f;registry&#x2f;entity&#x2f;IANA-IP-ARIN&#xa;&#xa;&#xa;&#x23;&#xa;&#x23; ARIN WHOIS data and services are subject to the Terms of Use&#xa;&#x23; available at&#x3a; https&#x3a;&#x2f;&#x2f;www.arin.net&#x2f;resources&#x2f;registry&#x2f;whois&#x2f;tou&#x2f;&#xa;&#x23;&#xa;&#x23; If you see inaccuracies in the results, please report at&#xa;&#x23; https&#x3a;&#x2f;&#x2f;www.arin.net&#x2f;resources&#x2f;registry&#x2f;whois&#x2f;inaccuracy_reporting&#x2f;&#xa;&#x23;&#xa;&#x23; Copyright 1997-2021, American Registry for Internet Numbers, Ltd.&#xa;&#x23;&#xa;&#xa;</pre></td></tr>
	<tr><td class="non-wrapping-label">Cookie &#x24;Version</td><td>1</pre></td></tr><tr><td class="non-wrapping-label">Cookie PHPSESSID</td><td>dc26a9108160513c58ae635241cb0ad1</pre></td></tr><tr><td class="non-wrapping-label">Cookie &#x24;Path</td><td>&#x2f;</pre></td></tr><tr><td class="non-wrapping-label">Cookie showhints</td><td>0</pre></td></tr>    
</table>
<div>&nbsp;</div><div>&nbsp;</div>
<table border="1px" width="75%" class="main-table-frame">
    <tr class="report-header"><td colspan="3">Info obtained by JavaScript</td></tr>
	<tr>
		<td class="non-wrapping-label">Browser Name</td>
		<td id="id_browser_td"></td>
	</tr>
	<tr>
		<td class="non-wrapping-label">Browser Codename</td>
		<td id="id_browser_codename_td"></td>
	</tr>
	<tr>
		<td class="non-wrapping-label">Browser Version</td>
		<td id="id_browser_version_td"></td>
	</tr>
	<tr>
		<td class="non-wrapping-label">Cookie Enabled?</td>
		<td id="id_cookie_enabled_td"></td>
	</tr>
	<tr>
		<td class="non-wrapping-label">Platform</td>
		<td id="id_platform_td"></td>
	</tr>
	<tr>
		<td class="non-wrapping-label">User Agent</td>
		<td id="id_user_agent_td"></td>
	</tr>
	<tr>
		<td class="non-wrapping-label">CPU Class</td>
		<td id="id_java_enabled_td"></td>
	</tr>
	<tr>
		<td class="non-wrapping-label">System Language</td>
		<td id="id_system_language_enabled_td"></td>
	</tr>
	<tr>
		<td class="non-wrapping-label">Resolution</td>
		<td id="id_resolution_enabled_td"></td>
	</tr>
	<tr>
		<td class="non-wrapping-label">Color Depth</td>
		<td id="id_color_depth_enabled_td"></td>
	</tr>
	<tr>
		<td class="non-wrapping-label">Referrer</td>
		<td id="id_referrer_td"></td>
	</tr>
	<tr>
		<td class="non-wrapping-label">Plug-Ins</td>
		<td id="id_plug_ins_td"></td>
	</tr>
</table>

<script type="text/javascript">

	var g_beSmart = true;
	var g_usingIE = ('all' in document);

	var outputValue = function(p_elementId, p_elementValue, p_beSmart, p_usingIE){
		if(p_beSmart){
			//safe
			if(p_usingIE){
				document.getElementById(p_elementId).innerText = p_elementValue;
			}else{
				document.getElementById(p_elementId).textContent = p_elementValue;
			}// end if
		}else{
			// unsafe and low-skill - should be using DOM interface
			document.getElementById(p_elementId).innerHTML = p_elementValue;
		}//end if
	}// end function

	outputValue("id_browser_td", navigator.appName, g_beSmart, g_usingIE);
	outputValue("id_browser_codename_td", navigator.appCodeName, g_beSmart, g_usingIE);
	outputValue("id_browser_version_td", navigator.appVersion, g_beSmart, g_usingIE);
	outputValue("id_cookie_enabled_td", navigator.cookieEnabled, g_beSmart, g_usingIE);
	outputValue("id_platform_td", navigator.platform, g_beSmart, g_usingIE);
	outputValue("id_user_agent_td", navigator.userAgent, g_beSmart, g_usingIE);
	outputValue("id_cpu_class_td", navigator.cpuClass, g_beSmart, g_usingIE);
	outputValue("id_java_enabled_td", navigator.javaEnabled, g_beSmart, g_usingIE);
	outputValue("id_system_language_enabled_td", navigator.systemLanguage, g_beSmart, g_usingIE);
	outputValue("id_resolution_enabled_td", screen.width+"x"+screen.height, g_beSmart, g_usingIE);
	outputValue("id_color_depth_enabled_td", screen.colorDepth, g_beSmart, g_usingIE);
	outputValue("id_referrer_td", document.referrer, g_beSmart, g_usingIE);

	if (navigator.appName=="Netscape"){
		for (i in navigator.plugins){
			l_plugins =+ navigator.plugins[i].name.toString() + ';';
		}// end for
		outputValue("id_plug_ins_td", l_plugins, g_beSmart, g_usingIE);
	}// end if
</script>

			<!-- End Content -->
		</blockquote>
			</td>
		</tr>
	</table>

<div class="footer">Browser: Mozilla&#x2f;4.5 &#x28;compatible&#x3b; HTTrack 3.0x&#x3b; Windows 98&#x29;</div><div class="footer">PHP Version: Not Available (Secure mode doesn't blab the server version)</div>
	<div class="footer">
		The newest version of 
		<a href="http://www.irongeek.com/i.php?page=security/mutillidae-deliberately-vulnerable-php-owasp-top-10" target="_blank">
			Mutillidae
		</a> 
		can downloaded from <a href="http://irongeek.com" target="_blank">Irongeek's Site</a>
	</div>
</body>
</html><script type="text/javascript">if(top != self) top.location.replace(location);</script><script type="text/javascript">
			try{
				window.localStorage.setItem("LocalStorageTarget","This is set by the index.php page");
				window.sessionStorage.setItem("SessionStorageTarget","This is set by the index.php page");
			}catch(e){
				alert(e);
			};
		</script>